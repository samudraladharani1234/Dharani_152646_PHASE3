package com.cg.paymentwalletappjpa.test;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

import com.cg.paymentwalletappjpa.dao.IPaymentDao;
import com.cg.paymentwalletappjpa.dao.PaymentDaoImpl;
import com.cg.paymentwalletappjpa.dto.Customer;
import com.cg.paymentwalletappjpa.dto.Wallet;
import com.cg.paymentwalletappjpa.exception.PaymentException;
import com.cg.paymentwalletappjpa.service.IPaymentService;
import com.cg.paymentwalletappjpa.service.PaymentServiceImpl;


public class TestValidation {
	IPaymentService service=new PaymentServiceImpl();
	IPaymentDao dao=new PaymentDaoImpl();

	@Test
	public void CheckForZeroDeposittest() throws PaymentException {
		boolean condition = false;
		Customer customer = new Customer();
		customer.setName("Dharani");
		customer.setPhNumber("7794908604");
		customer.setEmailId("dharani@gmail.com");
		customer.setUserId("dharani");
		Wallet wallet = new Wallet();
		wallet.setPassword("12345678");
		wallet.setTransaction("aaa");
		customer.setWallet(wallet);
		dao.createAccount(customer);
		condition = service.deposit("dharani", 0.0);
		assertFalse(condition);
	}

	@Test(expected = PaymentException.class)
	public void CheckForInvalidNameTest() throws PaymentException {
		Customer customer = new Customer();
		customer.setName("fd65f46");
		customer.setPhNumber("7794908604");
		customer.setEmailId("dharani@gmail.com");
		customer.setUserId("dharani");
		Wallet wallet = new Wallet();
		wallet.setPassword("12345678");
		wallet.setTransaction("aaa");
		customer.setWallet(wallet);
		service.validateDetails(customer);
	}

	@Test
	public void CheckForValidNameTest() throws PaymentException {
		Customer customer = new Customer();
		customer.setName("Dharani");
		customer.setPhNumber("7794908604");
		customer.setEmailId("dharani@gmail.com");
		customer.setUserId("dharani");
		Wallet wallet = new Wallet();
		wallet.setPassword("12345678");
		wallet.setTransaction("aaa");
		customer.setWallet(wallet);
		boolean condition = service.validateDetails(customer);
		assertTrue(condition);
	}

	@Test(expected = PaymentException.class)
	public void CheckForInvalidPhoneNumberTest() throws PaymentException {
		Customer customer = new Customer();
		customer.setName("Dharani");
		customer.setPhNumber("77949");
		customer.setEmailId("dharani@gmail.com");
		customer.setUserId("dharani");
		Wallet wallet = new Wallet();
		wallet.setPassword("12345678");
		wallet.setTransaction("aaa");
		customer.setWallet(wallet);
		boolean condition = service.validateDetails(customer);
		assertFalse(condition);
	}

	@Test
	public void CheckForValidPhoneNumberTest() throws PaymentException {
		Customer customer = new Customer();
		customer.setName("Dharani");
		customer.setPhNumber("7794908604");
		customer.setEmailId("dharani@gmail.com");
		customer.setUserId("dharani");
		Wallet wallet = new Wallet();
		wallet.setPassword("12345678");
		wallet.setTransaction("aaa");
		customer.setWallet(wallet);
		boolean condition = service.validateDetails(customer);
		assertTrue(condition);
	}

	@Test(expected = PaymentException.class)
	public void CheckForInvalidEmailTest() throws PaymentException {
		Customer customer = new Customer();
		customer.setName("Dharani");
		customer.setPhNumber("7794908604");
		customer.setEmailId("4gfgaff");
		customer.setUserId("dharani");
		Wallet wallet = new Wallet();
		wallet.setPassword("12345678");
		wallet.setTransaction("aaa");
		customer.setWallet(wallet);
		boolean condition = service.validateDetails(customer);
		assertFalse(condition);
	}

	@Test
	public void CheckForValidEmailTest() throws PaymentException {
		Customer customer = new Customer();
		customer.setName("Dharani");
		customer.setPhNumber("7794908604");
		customer.setEmailId("dharani@gmail.com");
		customer.setUserId("dharani");
		Wallet wallet = new Wallet();
		wallet.setPassword("12345678");
		wallet.setTransaction("aaa");
		customer.setWallet(wallet);
		boolean condition = service.validateDetails(customer);
		assertTrue(condition);
	}

	@Test(expected = PaymentException.class)
	public void CheckForInvalidUserId() throws PaymentException {
		Customer customer = new Customer();
		customer.setName("Dharani");
		customer.setPhNumber("7794908604");
		customer.setEmailId("dharani@gmail.com");
		customer.setUserId("abc");
		Wallet wallet = new Wallet();
		wallet.setPassword("12345678");
		wallet.setTransaction("aaa");
		customer.setWallet(wallet);
		boolean condition = service.validateDetails(customer);
		assertFalse(condition);

	}

	@Test
	public void CheckForValidUserId() throws PaymentException {
		Customer customer = new Customer();
		customer.setName("Dharani");
		customer.setPhNumber("7794908604");
		customer.setEmailId("dharani@gmail.com");
		customer.setUserId("dharani");
		Wallet wallet = new Wallet();
		wallet.setPassword("12345678");
		wallet.setTransaction("aaa");
		customer.setWallet(wallet);
		boolean condition = service.validateDetails(customer);
		assertTrue(condition);

	}

	@Test(expected = PaymentException.class)
	public void CheckForInvalidassword() throws PaymentException {
		Customer customer = new Customer();
		customer.setName("Dharani");
		customer.setPhNumber("7794908604");
		customer.setEmailId("dharani@gmail.com");
		customer.setUserId("dharani");
		Wallet wallet = new Wallet();
		wallet.setPassword("123");
		wallet.setTransaction("aaa");
		customer.setWallet(wallet);
		boolean condition = service.validateDetails(customer);
		assertFalse(condition);

	}

	@Test
	public void CheckForValidPassword() throws PaymentException {
		Customer customer = new Customer();
		customer.setName("Dharani");
		customer.setPhNumber("7794908604");
		customer.setEmailId("dharani@gmail.com");
		customer.setUserId("dharani");
		Wallet wallet = new Wallet();
		wallet.setPassword("12345678");
		wallet.setTransaction("aaa");
		customer.setWallet(wallet);
		boolean condition = service.validateDetails(customer);
		assertTrue(condition);

	}

}
